/* RTD10kB3950 is a simple, low cost, maximum precision formula for an RTD NTC (negative tempeture coeficient) 
  of 10Kohm at 25 degres C with a Beta of 3950.
  A Excel file will be join with the calculation table I used if you would like to use another Beta.
  Notice that if the resistance at 25C is different than 10K, the formula would be more difficult to addapt.


Formula is:

B = Beta,
T = current temperature
R25C = resistance of RTD at 25 Celsius
R = RTD resistance at current temp

    -------------------
    
    T = ( 1/ ( (1/B) * ln( R/R25C ) +  ( 1/298.00 ) )  -273 );
    
    -------------------

    ln in natural logarythme, will be log() fonction in arduino math.h library 

    File created 20/05/2015

    By Nitrof
*/

#include "Arduino.h"
#include "RTD10k.h"


    int input;
const int numReadings = 20; //set average to count
int readings[numReadings]; // the readings from the analog input
int total = 0;                  // the running total
int average = 0;                // the average

void RTD10k::initialize(float Vref,int reso) {
  _Vref = Vref;
  _reso = reso;

  // initialize all the readings to 0 for input reading loop:
  for (int thisReading = 0; thisReading < numReadings; thisReading++){
    readings[thisReading] = 0;
  }
}


void RTD10k::read(int selecInput) {//do reading loop

  //average calculation

for (int indexmoy = 0; indexmoy <= numReadings; indexmoy++) { // do reading loop until ''numReadings''
  input = analogRead(selecInput);
    _selecInput = selecInput;// will be use on serial print
    total = total - readings[indexmoy];     // subtract the last reading:
    readings[indexmoy] = input;     // read from the sensor:
    total = total + readings[indexmoy];       // add the reading to the total:
  }

  int average = total / numReadings;

  if (_reso = 10) {
    map(average, 0, 1023, 0, 4095); //mapping for 10bits resolution
  }

  //electric value calculation
  Vin = (average) * _Vref / 4095;
  int Rref = 10000;
  resistance = (Vin / (_Vref - Vin) * Rref);


_temp = (1/( (1/3950.00) * log(resistance/10000.00) +  (1/298.00) )  -273);  // resistance to temp formula
if (_temp < -50){
  _temp = -50;  
}
temp = _temp;

}


void RTD10k::serialInputMon(String(ipName)) {    ///print all value for an input on demande
  //print on serial port input reading  
  if (Serial.available() > 0) ; {
    Serial.println( "input; " + ipName + "; " + Vin + "Volt; R= " + resistance + " ohm Tempeture= " + temp + "C");
  }
}


///////////////****** calibration functions !!!

float RrefOffset[] = {0,0,0,0,0,0,0,0,0,0};

void RTD10k::runCalibration(int input){


for (int indexmoy = 0; indexmoy <= numReadings; indexmoy++) { // do reading loop until ''numReadings''
    total = total - readings[indexmoy];     // subtract the last reading:
    readings[indexmoy] = analogRead(input);     // read from the sensor:
    total = total + readings[indexmoy];       // add the reading to the total:
  }

  int average = total / numReadings;

  if (_reso = 10) {
    map(average, 0, 1023, 0, 4095); //mapping for 10bits resolution
  }

  //electric value calculation
  Vin = average * _Vref / 4095;
  int Rref = 10000;
  float realRref = (_Vref-Vin)*10000/Vin;
  RrefOffset[input] = 10000-realRref;

  if (Serial.available() > 0) ;{
    Serial.println(analogRead(input));
    Serial.println(average);
    Serial.println(String(_Vref) + "Vref" );
    Serial.println(String(Vin) += "Vin");
    Serial.println(realRref);
  }


  String prntStatus = "input " ;
  prntStatus += String(input) += ":";
  prntStatus +=  String(realRref) += "ohm , correction = ";
  prntStatus += String(RrefOffset[input]);

  if (Serial.available() > 0) ;{
    Serial.println(prntStatus);
  }

}

void RTD10k::calibrateRref(int input, int offset[]){



}

int average(int input){
  int output = 0;
  int count = 0;
  for (int i = 0; i <= 20; i++){
    count += input;

  }
  output = count/21;
  return output;

}