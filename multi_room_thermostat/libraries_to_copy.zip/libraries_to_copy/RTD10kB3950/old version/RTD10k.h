/* RTD10kB3950 is a simple, low cost, maximum precision formula for an RTD NTC (negative tempeture coeficient) 
  of 10Kohm at 25 degres C with a Beta of 3950.
  A Excel file will be join with the calculation table I used if you would like to use another Beta.
  Notice that if the resistance at 25C is different than 10K, the formula would be more difficult to addapt.


    File created 20/05/2015

    By Nitrof
*/

#ifndef RTD10k_h
#define RTD10k_h
#include "Arduino.h"
#include <math.h>
    
class RTD10k
{
  public:
    float temp;   //give tempeture
    float Vin;  //voltage to the analoge pin input
    float resistance;   //resistance in ohm of the RTD
    
    void initialize(float Vref,int reso = 10);  //referance voltage 3.3 or 5 V and input resolution
    void read(int selecInput);
    void serialInputMon(String StrInput);
    void runCalibration(int input);
    void calibrateRref(int input, int offset[]);

  private:
    int _selecInput;
    float _temp;
    int _reso;
    float _Vref;

};

#endif
