uHTTP SD DOCROOT
=====
<p align="right"><a href='https://pledgie.com/campaigns/28538'>
    <img alt='Click here to lend your support to: uHTTP and make a donation!' src='https://pledgie.com/campaigns/28538.png?skin_name=chrome' border='0' >
</a></p>

uHTTP SD Document Root is a simple sketch that show how simple is to serve files from SD Card.

This sketch is written by Filippo Sallemi <fsallemi@nomadnt.com>
